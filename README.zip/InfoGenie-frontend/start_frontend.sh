#!/bin/bash
npm start
